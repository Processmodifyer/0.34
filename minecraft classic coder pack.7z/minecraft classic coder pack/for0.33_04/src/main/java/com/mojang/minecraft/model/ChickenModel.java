package com.mojang.minecraft.model;

import com.mojang.util.MathHelper;

public class ChickenModel extends Model {

    public ModelPart head;
    public ModelPart body;
    public ModelPart rightLeg;
    public ModelPart leftLeg;
    public ModelPart rightWing;
    public ModelPart leftWing;
    public ModelPart bill;
    public ModelPart chin;

    public ChickenModel() {
    	this.headOffset = 1F;
    	byte var1 = 16;
    	this.head = new ModelPart(0, 0);
    	this.head.setBounds(-2F, -6F, -2F, 4, 6, 3, 0F);
    	this.head.setPosition(0F, -1 + var1, -4F);
    	this.bill = new ModelPart(14, 0);
        this.bill.setBounds(-2F, -4F, -4F, 4, 2, 2, 0F);
        this.bill.setPosition(0F, -1 + var1, -4F);
        this.chin = new ModelPart(14, 4);
        this.chin.setBounds(-1F, -2F, -3F, 2, 2, 2, 0F);
        this.chin.setPosition(0F, -1 + var1, -4F);
        this.body = new ModelPart(0, 9);
        this.body.setBounds(-3F, -4F, -3F, 6, 8, 6, 0F);
        this.body.setPosition(0F, var1, 0F);
        this.rightLeg = new ModelPart(26, 0);
        this.rightLeg.setBounds(-1F, 0F, -3F, 3, 5, 3, 0F);
        this.rightLeg.setPosition(-2F, 3 + var1, 1F);
        this.leftLeg = new ModelPart(26, 0);
        this.leftLeg.setBounds(-1F, 0F, -3F, 3, 5, 3, 0F);
        this.leftLeg.setPosition(1F, 3 + var1, 1F);
        this.rightWing = new ModelPart(24, 13);
        this.rightWing.setBounds(0F, 0F, -3F, 1, 4, 6, 0F);
        this.rightWing.setPosition(-4F, -3 + var1, 0F);
        this.leftWing = new ModelPart(24, 13);
        this.leftWing.setBounds(-1F, 0F, -3F, 1, 4, 6, 0F);
        this.leftWing.setPosition(4F, -3 + var1, 0F);
    }

    @Override
    public void render(float par2, float par3, float par4, float yawDegrees, float pitchDegrees, float scale) {
        setRotationAngles(par2, par3, par4, yawDegrees, pitchDegrees, scale);
        this.head.render(scale);
        this.bill.render(scale);
        this.chin.render(scale);
        this.body.render(scale);
        this.rightLeg.render(scale);
        this.leftLeg.render(scale);
        this.rightWing.render(scale);
        this.leftWing.render(scale);
    }

    public void setRotationAngles(float par1, float par2, float par3,
            float yawDegrees, float pitchDegrees, float scale) {
    	this.head.pitch = pitchDegrees / (180F / (float) Math.PI);
    	this.head.yaw = yawDegrees / (180F / (float) Math.PI);
    	this.bill.pitch = head.pitch;
    	this.bill.yaw = head.yaw;
    	this.chin.pitch = head.pitch;
    	this.chin.yaw = head.yaw;
    	this.body.pitch = (float) Math.PI / 2F;
    	this.rightLeg.pitch = MathHelper.cos(par1 * 0.6662F) * 1.4F * par2;
    	this.leftLeg.pitch = MathHelper.cos(par1 * 0.6662F + (float) Math.PI) * 1.4F * par2;
    	this.rightWing.roll = par3;
    	this.leftWing.roll = -par3;
    }
}