package com.mojang.minecraft;

import com.mojang.minecraft.level.Level;
import com.mojang.minecraft.mob.Mob;
import com.mojang.minecraft.mob.Zombie;
import com.mojang.minecraft.mob.ai.BasicAI;
import com.mojang.minecraft.mob.ai.BasicAttackAI;
import com.mojang.minecraft.model.ModelManager;
import com.mojang.minecraft.render.TextureManager;

public class ExampleMod extends MinecraftMod {
	public void RenderMob(final ModelManager model, final Mob moddedmob) {
		class MyMob extends Mob {

			public MyMob(Level var1, float var2, float var3, float var4, TextureManager var5) {
				super(var1);
			    this.setPos(var2, var3, var4);
			    
			    this.modelName = "zombie";		
				class MyMobAI extends BasicAI {

			}
		
		
		super.RenderMob(model, moddedmob, var5, var3, var4, var4, var4, var4, var4);
	}
	}
}
}


