// 
// Decompiled by Procyon v0.5.36
// 

package com.mojang.minecraft.item;

import com.mojang.minecraft.render.ShapeRenderer;
import org.lwjgl.opengl.GL11;
import com.mojang.minecraft.render.TextureManager;
import java.util.List;
import com.mojang.minecraft.phys.AABB;
import com.mojang.util.MathHelper;
import com.mojang.minecraft.player.Player;
import com.mojang.minecraft.level.Level;
import com.mojang.minecraft.Entity;

public class NewArrow extends Entity
{
    public static final long serialVersionUID = 0L;
    private float xd;
    private float yd;
    private float zd;
    private float yRot;
    private float xRot;
    private float yRotO;
    private float xRotO;
    private boolean hasHit;
    private int stickTime;
    private Entity owner;
    private int time;
    private int type;
    private float gravity;
    private int damage;
    
    public NewArrow(final Level var1, final Entity var2, float var3, final float var4, float var5, float var6, float var7, final float var8) {
        super(var1);
        this.hasHit = false;
        this.stickTime = 0;
        this.time = 0;
        this.type = 0;
        this.gravity = 0.0f;
        this.owner = var2;
        this.setSize(0.3f, 0.5f);
        this.heightOffset = this.bbHeight / 2.0f;
        this.damage = 3;
        if (!(var2 instanceof Player)) {
            this.type = 1;
        }
        else {
            this.damage = 7;
        }
        this.heightOffset = 0.25f;
        float var9 = MathHelper.cos(-var6 * 0.017453292f - 3.1415927f);
        final float var10 = MathHelper.sin(-var6 * 0.017453292f - 3.1415927f);
        var6 = MathHelper.cos(-var7 * 0.017453292f);
        var7 = MathHelper.sin(-var7 * 0.017453292f);
        this.slide = false;
        this.gravity = 1.0f / var8;
        this.xo -= var9 * 0.2f;
        this.zo += var10 * 0.2f;
        var3 -= var9 * 0.2f;
        var5 += var10 * 0.2f;
        this.xd = var10 * var6 * var8;
        this.yd = var7 * var8;
        this.zd = var9 * var6 * var8;
        this.setPos(var3, var4, var5);
        var9 = MathHelper.sqrt(this.xd * this.xd + this.zd * this.zd);
        final float n = (float)(Math.atan2(this.xd, this.zd) * 180.0 / 3.1415927410125732);
        this.yRot = n;
        this.yRotO = n;
        final float n2 = (float)(Math.atan2(this.yd, var9) * 180.0 / 3.1415927410125732);
        this.xRot = n2;
        this.xRotO = n2;
        this.makeStepSound = false;
    }
    
    public void tick() {
        ++this.time;
        this.xRotO = this.xRot;
        this.yRotO = this.yRot;
        this.xo = this.x;
        this.yo = this.y;
        this.zo = this.z;
        if (this.hasHit) {
            ++this.stickTime;
            if (this.type == 0) {
                if (this.stickTime >= 300 && Math.random() < 0.009999999776482582) {
                    this.remove();
                }
            }
            else if (this.type == 1 && this.stickTime >= 20) {
                this.remove();
            }
        }
        else {
            this.xd *= 0.998f;
            this.yd *= 0.998f;
            this.zd *= 0.998f;
            this.yd -= 0.02f * this.gravity;
            final int var1 = (int)(MathHelper.sqrt(this.xd * this.xd + this.yd * this.yd + this.zd * this.zd) / 0.2f + 1.0f);
            final float var2 = this.xd / var1;
            final float var3 = this.yd / var1;
            final float var4 = this.zd / var1;
            for (int var5 = 0; var5 < var1 && !this.collision; ++var5) {
                final AABB var6 = this.bb.expand(var2, var3, var4);
                if (this.level.getCubes(var6).size() > 0) {
                    this.collision = true;
                }
                final List<?> var7 = (List<?>)this.level.blockMap.getEntities((Entity)this, var6);
                for (int var8 = 0; var8 < var7.size(); ++var8) {
                    final Entity var9;
                    if ((var9 = (Entity)var7.get(var8)).isShootable() && (var9 != this.owner || this.time > 5)) {
                        var9.hurt((Entity)this, this.damage);
                        this.collision = true;
                        this.remove();
                        return;
                    }
                }
                if (!this.collision) {
                    this.bb.move(var2, var3, var4);
                    this.x += var2;
                    this.y += var3;
                    this.z += var4;
                    this.blockMap.moved((Entity)this);
                }
            }
            if (this.collision) {
                this.hasHit = true;
                final float xd = 0.0f;
                this.zd = xd;
                this.yd = xd;
                this.xd = xd;
                this.level.playSound("random.drr", (Entity)this, 0.5f, 0.8f + (float)Math.random());
            }
            if (!this.hasHit) {
                final float var10 = MathHelper.sqrt(this.xd * this.xd + this.zd * this.zd);
                this.yRot = (float)(Math.atan2(this.xd, this.zd) * 180.0 / 3.1415927410125732);
                this.xRot = (float)(Math.atan2(this.yd, var10) * 180.0 / 3.1415927410125732);
                while (this.xRot - this.xRotO < -180.0f) {
                    this.xRotO -= 360.0f;
                }
                while (this.xRot - this.xRotO >= 180.0f) {
                    this.xRotO += 360.0f;
                }
                while (this.yRot - this.yRotO < -180.0f) {
                    this.yRotO -= 360.0f;
                }
                while (this.yRot - this.yRotO >= 180.0f) {
                    this.yRotO += 360.0f;
                }
            }
        }
    }
    
    public void render(final TextureManager var1, float var2) {
        GL11.glBindTexture(3553, this.textureId = var1.load("/item/arrows.png"));
        final float var3 = this.level.getBrightness((int)this.x, (int)this.y, (int)this.z);
        GL11.glPushMatrix();
        GL11.glColor4f(var3, var3, var3, 1.0f);
        GL11.glTranslatef(this.xo + (this.x - this.xo) * var2, this.yo + (this.y - this.yo) * var2 - this.heightOffset / 2.0f, this.zo + (this.z - this.zo) * var2);
        GL11.glRotatef(this.yRotO + (this.yRot - this.yRotO) * var2 - 90.0f, 0.0f, 1.0f, 0.0f);
        GL11.glRotatef(this.xRotO + (this.xRot - this.xRotO) * var2, 0.0f, 0.0f, 1.0f);
        GL11.glRotatef(45.0f, 1.0f, 0.0f, 0.0f);
        final ShapeRenderer var4 = ShapeRenderer.instance;
        var2 = 0.5f;
        final float var5 = (0 + this.type * 10) / 32.0f;
        final float var6 = (5 + this.type * 10) / 32.0f;
        final float var7 = 0.15625f;
        final float var8 = (5 + this.type * 10) / 32.0f;
        final float var9 = (10 + this.type * 10) / 32.0f;
        final float var10 = 0.05625f;
        GL11.glScalef(0.05625f, var10, var10);
        GL11.glNormal3f(var10, 0.0f, 0.0f);
        var4.begin();
        var4.vertexUV(-7.0f, -2.0f, -2.0f, 0.0f, var8);
        var4.vertexUV(-7.0f, -2.0f, 2.0f, var7, var8);
        var4.vertexUV(-7.0f, 2.0f, 2.0f, var7, var9);
        var4.vertexUV(-7.0f, 2.0f, -2.0f, 0.0f, var9);
        var4.end();
        GL11.glNormal3f(-var10, 0.0f, 0.0f);
        var4.begin();
        var4.vertexUV(-7.0f, 2.0f, -2.0f, 0.0f, var8);
        var4.vertexUV(-7.0f, 2.0f, 2.0f, var7, var8);
        var4.vertexUV(-7.0f, -2.0f, 2.0f, var7, var9);
        var4.vertexUV(-7.0f, -2.0f, -2.0f, 0.0f, var9);
        var4.end();
        for (int var11 = 0; var11 < 4; ++var11) {
            GL11.glRotatef(90.0f, 1.0f, 0.0f, 0.0f);
            GL11.glNormal3f(0.0f, -var10, 0.0f);
            var4.vertexUV(-8.0f, -2.0f, 0.0f, 0.0f, var5);
            var4.vertexUV(8.0f, -2.0f, 0.0f, var2, var5);
            var4.vertexUV(8.0f, 2.0f, 0.0f, var2, var6);
            var4.vertexUV(-8.0f, 2.0f, 0.0f, 0.0f, var6);
            var4.end();
        }
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        GL11.glPopMatrix();
    }
    
    public void awardKillScore(final Entity var1, final int var2) {
        this.owner.awardKillScore(var1, var2);
    }
    
    public Entity getOwner() {
        return this.owner;
    }
    
    public void playerTouch(final Entity var1) {
        final Player var2 = (Player)var1;
        if (this.hasHit && this.owner == var2 && var2.arrows < 99) {
            this.level.addEntity((Entity)new TakeEntityAnim(this.level, (Entity)this, (Entity)var2));
            this.level.playSound2("random.pop", (Entity)this, 0.5f, 0.8f + (float)Math.random());
            final Player player = var2;
            ++player.arrows;
            this.remove();
        }
    }
}