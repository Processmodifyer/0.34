package com.mojang.minecraft.model;

import com.mojang.util.MathHelper;

public final class SkeletonModel extends HumanoidModel {

   public SkeletonModel() {
      this.rightArm = new ModelPart(40, 16);
      this.rightArm.setBounds(-1.0F, -2.0F, -1.0F, 2, 12, 2, 0.0F);
      this.rightArm.setPosition(-5.0F, 2.0F, 0.0F);
      this.leftArm = new ModelPart(40, 16);
      this.leftArm.mirror = true;
      this.leftArm.setBounds(-1.0F, -2.0F, -1.0F, 2, 12, 2, 0.0F);
      this.leftArm.setPosition(5.0F, 2.0F, 0.0F);
      this.rightLeg = new ModelPart(0, 16);
      this.rightLeg.setBounds(-1.0F, 0.0F, -1.0F, 2, 12, 2, 0.0F);
      this.rightLeg.setPosition(-2.0F, 12.0F, 0.0F);
      this.leftLeg = new ModelPart(0, 16);
      this.leftLeg.mirror = true;
      this.leftLeg.setBounds(-1.0F, 0.0F, -1.0F, 2, 12, 2, 0.0F);
      this.leftLeg.setPosition(2.0F, 12.0F, 0.0F);
   }
   public final void setRotationAngles(float var1, float var2, float var3, float var4, float var5, float var6) {
	      super.setRotationAngles(var1, var2, var3, var4, var5, var6);
	      var1 = MathHelper.sin(this.attackOffset * 3.1415927F);
	      var2 = MathHelper.sin((1.0F - (1.0F - this.attackOffset) * (1.0F - this.attackOffset)) * 3.1415927F);

	   }   
}
