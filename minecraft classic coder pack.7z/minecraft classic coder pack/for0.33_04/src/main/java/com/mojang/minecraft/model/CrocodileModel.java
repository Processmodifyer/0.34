package com.mojang.minecraft.model;

import com.mojang.util.MathHelper;

public class CrocodileModel extends Model {

    // fields

    ModelPart tail;
    ModelPart head;
    ModelPart body;
    ModelPart leg1;
    ModelPart leg2;
    ModelPart leg4;
    ModelPart leg3;

    public CrocodileModel() {
        this.headOffset = 0.937F;
        this.tail = new ModelPart(0, 0);
        this.tail.setBounds(0F, 0F, 0F, 8, 2, 17, 0F);
        this.tail.setPosition(-4F, 11F, 5F);
        this.tail.pitch = 0F;
        this.tail.yaw = 0F;
        this.tail.roll = 0F;
        this.tail.mirror = false;
        this.head = new ModelPart(0, 0);
        this.head.setBounds(-4F, -4F, -8F, 8, 5, 11, 0F);
        this.head.setPosition(0F, 15F, -9F);
        this.head.pitch = 0F;
        this.head.yaw = 0F;
        this.head.roll = 0F;
        this.head.mirror = false;
        this.body = new ModelPart(28, 8);
        this.body.setBounds(-5F, -10F, -7F, 10, 16, 8, 0F);
        this.body.setPosition(0F, 11F, 2F);
        this.body.pitch = 1.5708F;
        this.body.yaw = 0F;
        this.body.roll = 0F;
        this.body.mirror = false;
        this.leg1 = new ModelPart(0, 16);
        this.leg1.setBounds(-2F, 0F, -2F, 4, 6, 4, 0F);
        this.leg1.setPosition(-3F, 18F, 7F);
        this.leg1.pitch = 0F;
        this.leg1.yaw = 0F;
        this.leg1.roll = 0F;
        this.leg1.mirror = false;
        this.leg2 = new ModelPart(0, 16);
        this.leg2.setBounds(-2F, 0F, -2F, 4, 6, 4, 0F);
        this.leg2.setPosition(3F, 18F, 7F);
        this.leg2.pitch = 0F;
        this.leg2.yaw = 0F;
        this.leg2.roll = 0F;
        this.leg2.mirror = false;
        this.leg4 = new ModelPart(0, 16);
        this.leg4.setBounds(-2F, 0F, -2F, 4, 6, 4, 0F);
        this.leg4.setPosition(3F, 18F, -5F);
        this.leg4.pitch = 0F;
        this.leg4.yaw = 0F;
        this.leg4.roll = 0F;
        this.leg4.mirror = false;
        this.leg3 = new ModelPart(0, 16);
        this.leg3.setBounds(-2F, 18F, -2F, 4, 6, 4, 0F);
        this.leg3.setPosition(-3F, 0F, -5F);
        this.leg3.pitch = 0F;
        this.leg3.yaw = 0F;
        this.leg3.roll = 0F;
        this.leg3.mirror = false;
    }

    @Override
    public void render(float f, float f1, float f2, float yawDegrees, float pitchDegrees, float scale) {
        super.render(f, f1, f2, yawDegrees, pitchDegrees, scale);
        setRotationAngles(f, f1, f2, yawDegrees, pitchDegrees, scale);
        this.tail.render(scale);
        this.head.render(scale);
        this.body.render(scale);
        this.leg1.render(scale);
        this.leg2.render(scale);
        this.leg4.render(scale);
        this.leg3.render(scale);
    }

    public void setRotationAngles(float f, float f1, float f2, float yawDegrees, float pitchDegrees, float scale) {
        // super.setRotationAngles(f, f1, f2, f3, f4, f5);
    	this.tail.yaw = MathHelper.cos(f / (0.9595538255F) * (float) (Math.PI / 90) * f1 + 0);
    }
}