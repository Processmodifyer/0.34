package com.mojang.minecraft.model;

public class VillagerModel extends Model {
		
	   public ModelPart head;
	   public ModelPart headwear;
	   public ModelPart body;
	   public ModelPart Arm;
	   public ModelPart rightLeg;
	   public ModelPart leftLeg;
	   
 public VillagerModel(float var1) {
     this.head = new ModelPart(0, 0);
     this.head.setBounds(-4.0F, -8.0F, -4.0F, 8, 8, 8, var1);
     this.headwear = new ModelPart(32, 0);
     this.headwear.setBounds(-4.0F, -8.0F, -4.0F, 8, 8, 8, var1 + 0.5F);
     this.body = new ModelPart(16, 16);
     this.body.setBounds(-4.0F, 0.0F, -2.0F, 8, 12, 4, var1);
     this.Arm.setBounds(-3.0F, -2.0F, -2.0F, 4, 12, 4, var1);
     this.Arm.setPosition(-5.0F, 2.0F, 0.0F);
     this.rightLeg = new ModelPart(0, 16);
     this.rightLeg.setBounds(-2.0F, 0.0F, -2.0F, 4, 12, 4, var1);
     this.rightLeg.setPosition(-2.0F, 12.0F, 0.0F);
     this.leftLeg = new ModelPart(0, 16);
     this.leftLeg.mirror = true;
     this.leftLeg.setBounds(-2.0F, 0.0F, -2.0F, 4, 12, 4, var1);
     this.leftLeg.setPosition(2.0F, 12.0F, 0.0F);	 
}

}
