package com.mojang.minecraft.gamemode;

import com.mojang.minecraft.Minecraft;
import com.mojang.minecraft.SessionData;
import com.mojang.minecraft.gui.BlockSelectScreen;
import com.mojang.minecraft.level.Level;
import com.mojang.minecraft.level.MobSpawner;
import com.mojang.minecraft.level.tile.Block;
import com.mojang.minecraft.mob.Mob;
import com.mojang.minecraft.player.Player;

public class CreativeGameMode extends GameMode
{
	private MobSpawner spawner;

	public CreativeGameMode(Minecraft minecraft)
	{
		super(minecraft);

	}

	@Override
	public void apply(Level level)
	{
		super.apply(level);

		spawner = new MobSpawner(level);

		level.creativeMode = true;
		level.growTrees = true;
	}

	@Override
	public void openInventory()
	{
		BlockSelectScreen blockSelectScreen = new BlockSelectScreen();

		minecraft.setCurrentScreen(blockSelectScreen);
	}

	@Override
	public boolean isSurvival()
	{
		return false;
	}

	@Override
	public void apply(Player player)
	{
		for(int slot = 0; slot < 9; slot++)
		{
			player.inventory.count[slot] = 1;

			if(player.inventory.slots[slot] <= 0)
			{
				player.inventory.slots[slot] = ((Block) SessionData.allowedBlocks.get(slot)).id;	
				}
		}
	}

		@Override
		public void spawnMob()
		{
			int area = spawner.level.width * spawner.level.height * spawner.level.depth / 64 / 64 / 64;

			if(spawner.level.random.nextInt(100) < area && spawner.level.countInstanceOf(Mob.class) < area * 20)
			{
				spawner.spawn(area, spawner.level.player, null);
			}

		}

		@Override
		public void prepareLevel(Level level)
		{
			spawner = new MobSpawner(level);

			minecraft.progressBar.setText("Spawning..");

			int area = level.width * level.height * level.depth / 800;
			
			spawner.spawn(area, null, minecraft.progressBar);
		}
	}

