package com.mojang.minecraft.level.tile;

public class PoisonedAppleItem extends AppleItem {

	protected PoisonedAppleItem(int id, int textureID) {
	      super(60, 50);
	}

}
