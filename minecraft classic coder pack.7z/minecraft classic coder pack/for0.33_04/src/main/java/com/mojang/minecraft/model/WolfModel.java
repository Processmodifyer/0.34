package com.mojang.minecraft.model;

import com.mojang.util.MathHelper;

public class WolfModel extends Model
{
    /** main box for the wolf head */
    ModelPart wolfHeadMain;

    /** The wolf's body */
    ModelPart wolfBody;

    /** Wolf'se first leg */
    ModelPart wolfLeg1;

    /** Wolf's second leg */
    ModelPart wolfLeg2;

    /** Wolf's third leg */
    ModelPart wolfLeg3;

    /** Wolf's fourth leg */
    ModelPart wolfLeg4;

    /** The wolf's tail */
    ModelPart wolfTail;

    /** The wolf's mane */
    ModelPart wolfMane;

    public WolfModel()
    {
        float var1 = 0.0F;
        float var2 = 13.5F;
        this.wolfHeadMain = new ModelPart(0, 0);
        this.wolfHeadMain.setBounds(-3.0F, -3.0F, -2.0F, 6, 6, 4, var1);
        this.wolfHeadMain.setPosition(-1.0F, var2, -7.0F);
        this.wolfBody = new ModelPart(18, 14);
        this.wolfBody.setBounds(-4.0F, -2.0F, -3.0F, 6, 9, 6, var1);
        this.wolfBody.setPosition(0.0F, 14.0F, 2.0F);
        this.wolfMane = new ModelPart(21, 0);
        this.wolfMane.setBounds(-4.0F, -3.0F, -3.0F, 8, 6, 7, var1);
        this.wolfMane.setPosition(-1.0F, 14.0F, 2.0F);
        this.wolfLeg1 = new ModelPart(0, 18);
        this.wolfLeg1.setBounds(-1.0F, 0.0F, -1.0F, 2, 8, 2, var1);
        this.wolfLeg1.setPosition(-2.5F, 16.0F, 7.0F);
        this.wolfLeg2 = new ModelPart(0, 18);
        this.wolfLeg2.setBounds(-1.0F, 0.0F, -1.0F, 2, 8, 2, var1);
        this.wolfLeg2.setPosition(0.5F, 16.0F, 7.0F);
        this.wolfLeg3 = new ModelPart(0, 18);
        this.wolfLeg3.setBounds(-1.0F, 0.0F, -1.0F, 2, 8, 2, var1);
        this.wolfLeg3.setPosition(-2.5F, 16.0F, -4.0F);
        this.wolfLeg4 = new ModelPart(0, 18);
        this.wolfLeg4.setBounds(-1.0F, 0.0F, -1.0F, 2, 8, 2, var1);
        this.wolfLeg4.setPosition(0.5F, 16.0F, -4.0F);
        this.wolfTail = new ModelPart(9, 18);
        this.wolfTail.setBounds(-1.0F, 0.0F, -1.0F, 2, 8, 2, var1);
        this.wolfTail.setPosition(-1.0F, 12.0F, 8.0F);
    }
    public final void render(float par2, float par3, float par4,
            float yawDegrees, float pitchDegrees, float scale) {
        setRotationAngles(par2, par3, par4, yawDegrees, pitchDegrees, scale);    	
    	wolfHeadMain.render(scale);
    	wolfBody.render(scale);
    	wolfMane.render(scale);
    	wolfLeg1.render(scale);
    	wolfLeg2.render(scale);
    	wolfLeg3.render(scale);
    	wolfLeg4.render(scale);
    	wolfTail.render(scale);
    } 
    public void setRotationAngles(float par1, float par2, float par3,
            float yawDegrees, float pitchDegrees, float scale) {
    	this.wolfHeadMain.pitch = pitchDegrees / (180F / (float) Math.PI);
    	this.wolfHeadMain.yaw = yawDegrees / (180F / (float) Math.PI);
    	this.wolfBody.pitch = (float) Math.PI / 2F;
    	this.wolfLeg1.pitch = MathHelper.cos(par1 * 0.6662F) * 1.4F * par2;
    	this.wolfLeg2.pitch = MathHelper.cos(par1 * 0.6662F + (float) Math.PI) * 1.4F * par2;
    	this.wolfLeg3.pitch = MathHelper.cos(par1 * 0.6662F) * 1.4F * par2;    	
    	this.wolfLeg4.pitch = MathHelper.cos(par1 * 0.6662F + (float) Math.PI) * 1.4F * par2;
    	this.wolfMane.pitch = wolfHeadMain.pitch;
    	this.wolfMane.yaw = wolfHeadMain.yaw;    	
    	this.wolfTail.roll = par3;
    	
    }    
}