package com.mojang.minecraft.model;


public abstract class Model {

   public float attackOffset;
   public float headOffset;


   public void render(float var1, float var2, float var3, float var4, float var5, float var6) {}
}
