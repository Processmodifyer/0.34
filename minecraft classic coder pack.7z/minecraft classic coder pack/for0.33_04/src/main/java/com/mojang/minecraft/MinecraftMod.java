package com.mojang.minecraft;

import com.mojang.minecraft.level.generator.LevelGenerator;
import com.mojang.minecraft.level.tile.Block;
import com.mojang.minecraft.mob.Mob;
import com.mojang.minecraft.mob.ai.BasicAI;
import com.mojang.minecraft.model.ModelManager;
import com.mojang.minecraft.render.TextureManager;

public class MinecraftMod {
	public String Name, Version, ID = this.getClass().getName();
	
	public void Tick(Entity entitymod, Block moddedblock, BasicAI customai) {
		
	}
	
	public void RenderMob(ModelManager model, Mob moddedmob, TextureManager var1, float var2, float var3, float var4, float var5, float var6, float var7) {

    }
    public void CustomLevelGenerator(LevelGenerator generator) {
    	
    }
}
