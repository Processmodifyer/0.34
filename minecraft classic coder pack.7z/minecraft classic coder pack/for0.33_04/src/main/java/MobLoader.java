import com.mojang.minecraft.level.Level;
import com.mojang.minecraft.mob.Mob;
public class MobLoader {
  public void Mods() {
	  
	  
   }
}
