
public class Greeting {

}
