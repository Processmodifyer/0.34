package com.mojang.minecraft.player;

public class InputHandler
{
	public float xxa = 0.0F;
	public float yya = 0.0F;
	public boolean jumping = false;

	public boolean running = false;

	public void updateMovement()
	{
	}

	public void resetKeys()
	{
	}

	public void setKeyState(int key, boolean state)
	{
	}
}
