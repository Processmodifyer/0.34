package com.mojang.minecraft.mob;

import com.mojang.minecraft.level.Level;
import com.mojang.minecraft.model.HumanoidModel;
import com.mojang.minecraft.model.Model;
import com.mojang.minecraft.render.TextureManager;
import org.lwjgl.opengl.GL11;

public class HumanoidMob extends Mob {

   public static final long serialVersionUID = 0L;


   public HumanoidMob(Level var1, float var2, float var3, float var4) {
      super(var1);
      this.modelName = "humanoid";
      this.heightOffset = 1.62F;      
      this.setPos(var2, var3, var4);
   }

   public void renderModel(TextureManager var1, float var2, float var3, float var4, float var5, float var6, float var7) {
      super.renderModel(var1, var2, var3, var4, var5, var6, var7);
      Model var9 = modelCache.getModel(this.modelName);
      GL11.glEnable(3008);
      if(this.allowAlpha) {
         GL11.glEnable(2884);
      }

      if(this.hasHair) {
         GL11.glDisable(2884);
         HumanoidModel var10 = null;
         (var10 = (HumanoidModel)var9).headwear.yaw = var10.head.yaw;
         var10.headwear.pitch = var10.head.pitch;
         var10.headwear.render(var7);
         GL11.glEnable(2884);
      }

      GL11.glDisable(3008);
   }
}
