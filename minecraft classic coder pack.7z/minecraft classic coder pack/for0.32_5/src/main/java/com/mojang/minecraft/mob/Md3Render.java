package com.mojang.minecraft.mob;

import com.mojang.minecraft.Minecraft;

public class Md3Render {


	public Minecraft put(String string) {
		// TODO Auto-generated method stub
		return null;
	}

}
