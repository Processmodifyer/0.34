package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.level.Level;

public class AppleItem extends DragableItem {

	protected AppleItem(int id, int textureID) {
	      super(60, 50);
	}
}
