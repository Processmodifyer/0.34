package com.mojang.minecraft.mob;

import com.mojang.minecraft.level.tile.Tile$SoundType;

public enum Mob$SoundType {

   none("none", 0, "-", 0.0F, 0.0F),
   pig("pig", 1, "pig", 0.6F, 1.0F),
   pighurt("pighurt", 2, "pighurt", 0.7F, 1.2F),
   pigdeath("pigdeath", 3, "pigdeath", 1.0F, 1.0F),
   sheep("sheep", 4, "sheep", 1.0F, 1.0F);
   private float volume;
   private float pitch;
   private static final Mob$SoundType[] values = new Mob$SoundType[]{none, pig, pighurt, pigdeath, sheep};
   private String name;


   private Mob$SoundType(String var1, int var2, String var3, float var4, float var5) {
      this.name = var3;
      this.volume = var4;
      this.pitch = var5;
   }

   public final float getVolume() {
      return this.volume  * 0.4F + 1.0F * 0.5F;
   }

   public final float getPitch() {
      return this.pitch /  0.2F + 0.9F;
   }


}