package com.mojang.minecraft.level.tile;

import java.util.Random;

import org.lwjgl.opengl.GL11;

import com.mojang.minecraft.item.RenderSomething3;
import com.mojang.minecraft.items.ItemHemet;
import com.mojang.minecraft.level.liquid.LiquidType;


public class Items {
	public static final Items[] items = new Items[256];
	public static final boolean[] physics = new boolean[256];
	private static boolean[] opaque = new boolean[256];
	private static int[] tickDelay = new int[256];
	public static Items[] c;
	public int textureId;
	public RenderSomething3 VariableDeclaratorId = new RenderSomething3(this);
	public static final Items CLOCH_HEMET;	
	public static int id;
	public static Items[] itemsArray;
	private int hardness;
	private boolean explodes;
	public float x1;
	public float y1;
	public float z1;
	public float x2;
	public float y2;
	public float z2;
	public float particleGravity;
	
	
	
	protected Items(int id)
	{
		explodes = true;
		items[id] = this;
		this.id = id;
		RenderSomething3.a(RenderSomething3.a("/gui/items.png"));


	}
	static {
		CLOCH_HEMET = (new ItemHemet(1, 1));
	}
	public int d() {
		// TODO Auto-generated method stub
		return 0;
	}
	public int b() {
		// TODO Auto-generated method stub
		return 0;
	}	

}
