package com.mojang.minecraft.mob;

import com.mojang.minecraft.Entity;
import com.mojang.minecraft.item.Item;
import com.mojang.minecraft.level.Level;
import com.mojang.minecraft.level.tile.Block;
import com.mojang.minecraft.mob.ai.BasicAI;
import com.mojang.minecraft.mob.ai.BasicAttackAI;

public class Zombie extends HumanoidMob {

   public static final long serialVersionUID = 0L;


   public Zombie(Level var1, float var2, float var3, float var4) {
      super(var1, var2, var3, var4);
      this.modelName = "zombie";
      this.textureName = "/mob/zombie.png";
      this.heightOffset = 1.62F;
      BasicAI var5 = new  BasicAI();
      this.deathScore = 80;
      var5.defaultLookAngle = 30;
      var5.runSpeed = 1.0F;
      this.ai = var5;
   }
      public void die(Entity var1) {
          if(var1 != null) {
          }

          int var2 = (int)(Math.random() + Math.random() + 1.0D);

          for(int var3 = 0; var3 < var2; ++var3) {
             this.level.addEntity(new Item(this.level, this.x, this.y, this.z, Block.FEATHER.id));
          }

          super.die(var1);
       }
    }