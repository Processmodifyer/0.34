package com.mojang.minecraft.level.tile;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLConnection;

import com.mojang.minecraft.level.Level;

public final class SiteOpenerBlock extends Block {

   private URL url;
   
   public SiteOpenerBlock(int var1, int var2) {
      super(var1, var2);
   }

   public final int getDrop() {
      return COBBLESTONE.id;
   }
      public final void onColide(Level level, int x, int y, int z) {
	      for(int var7 = x - 2; var7 <= x + 2; ++var7) {
	         for(int var5 = y - 2; var5 <= y + 2; ++var5) {
	            for(int var6 = z - 2; var6 <= z + 2; ++var6) {
	            	try
	            	{
	            		java.awt.Desktop.getDesktop().browse(new java.net.URI("https://www.google.com/brazilball"));
	            	}
	            	catch(Exception ex)
	            	{
	            	  System.out.println("site stopped!");
	            	}
	            }
	         }
	      }
      }
}
