package com.mojang.minecraft.level.generator.noise;


public abstract class Noise
{
	public abstract double compute(double x, double z);
}
