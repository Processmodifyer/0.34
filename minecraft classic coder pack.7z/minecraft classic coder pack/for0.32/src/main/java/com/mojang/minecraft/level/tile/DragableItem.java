package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.level.Level;
import com.mojang.minecraft.level.tile.Block;
import com.mojang.minecraft.level.tile.FlowerBlock;

public class DragableItem extends FlowerBlock {

	protected DragableItem(int id, int textureID) {
		this(id, textureID, null);

		textureId = textureID;
	}

	public DragableItem(int id, int i, Block[] minableBlocks) {
		super(id, 0);
	}
	
	

	protected int getTextureId(int texture)
	{
		return textureId;
	}
	   public void onAdded(Level level, int x, int y, int z) {
		      for(int var7 = x - 2; var7 <= x + 2; ++var7) {
		         for(int var5 = y - 2; var5 <= y + 2; ++var5) {
		            for(int var6 = z - 2; var6 <= z + 2; ++var6) {
		                level.setTile(x, y, z, 0);
		               }
		            }
		         }
		      }
}	

