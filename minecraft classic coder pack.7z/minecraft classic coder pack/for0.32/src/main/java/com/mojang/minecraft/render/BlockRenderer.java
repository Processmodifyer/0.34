package com.mojang.minecraft.render;

import com.mojang.minecraft.level.tile.Block;

public class BlockRenderer {

	public void a(Block block) {
		// TODO Auto-generated method stub
		
	}

}
