package com.mojang.minecraft.item;

import javax.imageio.ImageIO;

import org.eclipse.jdt.annotation.NonNull;

import com.mojang.minecraft.level.tile.Items;

import java.net.URL;
import java.net.HttpURLConnection;
import java.awt.image.BufferedImage;

public final class RenderSomething3
{
    public BufferedImage a;
    public int b;
    public int c;
    public boolean d;
    
    public RenderSomething3(final String s, final Texture texture) {
        this.b = 1;
        this.c = -1;
        this.d = false;
        new Thread() {
            public final void run() {
                @NonNull
				HttpURLConnection httpURLConnection = null;
                try {
                    (httpURLConnection = (HttpURLConnection)new URL(s).openConnection()).setDoInput(true);
                    httpURLConnection.setDoOutput(false);
                    httpURLConnection.connect();
                    if (httpURLConnection.getResponseCode() == 404) {
                        return;
                    }
                    if (texture == null) {
                        RenderSomething3.this.a = ImageIO.read(httpURLConnection.getInputStream());
                    }
                    else {
                        RenderSomething3.this.a = texture.a(ImageIO.read(httpURLConnection.getInputStream()));
                    }
                }
                catch (Exception ex) {
                    ex.printStackTrace();
                }
                finally {
                    httpURLConnection.disconnect();
                }
            }
        }.start();
    }

	public RenderSomething3(Items items) {
		// TODO Auto-generated constructor stub
	}

	public static Object a(Object object) {
		// TODO Auto-generated method stub
		return null;
	}
}
