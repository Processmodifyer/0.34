package com.mojang.minecraft.render;

import com.mojang.minecraft.level.tile.Block;
import com.mojang.minecraft.level.tile.Items;

public final class ItemStack
{
    public int size;
    public int b;
    public int c;
    public int d;
    
    public ItemStack(final Block block) {
        this(block, 1);
    }
    
    public ItemStack(final Block block, final int n) {
        this(block.id, n);
    }
    
    public ItemStack(final Items item) {
        this(item, 1);
    }
    
    public ItemStack(final Items item, final int n) {
        this(item.id, n);
    }
    
    public ItemStack(final int n) {
        this(n, 1);
    }
    
    public ItemStack(final int c, final int size) {
        this.size = 0;
        this.c = c;
        this.size = size;
    }
    
    public ItemStack(final int c, final int size, final int d) {
        this.size = 0;
        this.c = c;
        this.size = size;
        this.d = d;
    }
    
    
    public final ItemStack a(final int n) {
        this.size -= n;
        return new ItemStack(this.c, n, this.d);
    }
    
    public final Items a() {
        return Items.itemsArray[this.c];
    }
    
    
    public final int b() {
        return Items.itemsArray[this.c].d();
    }
    
    public final void damageItem(final int n) {
        this.d += n;
        if (this.d > this.b()) {
            --this.size;
            if (this.size < 0) {
                this.size = 0;
            }
            this.d = 0;
        }
    }
}