package com.mojang.minecraft.render;

import java.awt.Graphics;
import java.awt.image.DataBufferInt;
import java.awt.image.ImageObserver;
import java.awt.Image;
import java.awt.image.BufferedImage;

public class Texture
{
    private int[] a;
    private int b;
    private int c;
    
    public BufferedImage a(final BufferedImage bufferedImage) {
        this.b = 64;
        this.c = 32;
        final BufferedImage bufferedImage2;
        final Graphics graphics;
        (graphics = (bufferedImage2 = new BufferedImage(this.b, this.c, 2)).getGraphics()).drawImage(bufferedImage, 0, 0, null);
        graphics.dispose();
        this.a = ((DataBufferInt)bufferedImage2.getRaster().getDataBuffer()).getData();
        this.b(0, 0, 32, 16);
        this.a(32, 0, 64, 32);
        this.b(0, 16, 64, 32);
        return bufferedImage2;
    }
    
    private void a(int i, int j, int n, int n2) {
        final int n3 = 32;
        final int n4 = 0;
        final int n5 = 64;
        final int n6 = 32;
        n2 = n5;
        n = n4;
        j = (j = n3);
    Label_0076:
        while (true) {
            while (j < n2) {
                for (int k = n; k < n6; ++k) {
                    if (this.a[j + k * this.b] >>> 24 < 128) {
                        final boolean b = true;
                        break Label_0076;
                    }
                }
                ++j;
                continue;
            }
            final boolean b = false;
            continue Label_0076;
        }
    }
    
    private void b(int i, final int n, final int n2, final int n3) {
        int j;
        int[] a;
        int n4;
        for (i = 0; i < n2; ++i) {
            for (j = n; j < n3; ++j) {
                a = this.a;
                n4 = i + j * this.b;
                a[n4] |= 0xFF000000;
            }
        }
    }
}