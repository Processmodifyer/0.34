package com.mojang.minecraft.items;

import com.mojang.minecraft.level.tile.Items;

public class ItemHemet extends Items {

	   public ItemHemet(int var1, int var2) {
		      super(var1);
		   }

	}


