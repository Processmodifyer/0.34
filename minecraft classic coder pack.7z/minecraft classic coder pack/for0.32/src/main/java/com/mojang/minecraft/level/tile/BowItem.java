package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.Entity;
import com.mojang.minecraft.item.Arrow;
import com.mojang.minecraft.level.Level;
import com.mojang.minecraft.player.Player;
import com.mojang.minecraft.render.ItemStack;

public class BowItem extends DragableItem {

	private Level level;
	private Entity player;
	protected BowItem(int id, int textureID) {
		super(63, 53);
		
	}
}

