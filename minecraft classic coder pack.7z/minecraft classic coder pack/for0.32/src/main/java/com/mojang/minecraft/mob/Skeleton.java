package com.mojang.minecraft.mob;

import com.mojang.minecraft.Entity;
import com.mojang.minecraft.item.Arrow;
import com.mojang.minecraft.item.Item;
import com.mojang.minecraft.level.Level;
import com.mojang.minecraft.level.tile.Block;
import com.mojang.minecraft.mob.ai.BasicAttackAI;

public class Skeleton extends HumanoidMob {

   public static final long serialVersionUID = 0L;


   public Skeleton(Level var1, float var2, float var3, float var4) {
      super(var1, var2, var3, var4);
      this.modelName = "skeleton";
      this.textureName = "/mob/skeleton.png";
      BasicAttackAI var5 = new BasicAttackAI();
      this.deathScore = 120;
      this.heightOffset = 1.62F;      
      var5.runSpeed = 0.3F;
      var5.damage = 3;
      this.ai = var5;
   }

   public void shootArrow(Level var1) {
   }

   // $FF: synthetic method
   static void shootRandomArrow(Skeleton var0) {
      var0 = var0;
      int var1 = (int)((Math.random() + Math.random()) * 3.0D + 4.0D);

      for(int var2 = 0; var2 < var1; ++var2) {
      }
      }
      public void die(Entity var1) {
          if(var1 != null) {
          }

          int var2 = (int)(Math.random() + Math.random() + 1.0D);

          for(int var3 = 0; var3 < var2; ++var3) {
             this.level.addEntity(new Item(this.level, this.x, this.y, this.z, Block.ARROW.id));
          }

          super.die(var1);
       }
     {}
   }

