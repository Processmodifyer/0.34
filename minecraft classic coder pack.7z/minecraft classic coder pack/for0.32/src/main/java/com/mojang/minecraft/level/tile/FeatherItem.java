package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.level.Level;

public class FeatherItem extends DragableItem {

	protected FeatherItem(int id, int textureID) {
	      super(61, 51);
	}
}