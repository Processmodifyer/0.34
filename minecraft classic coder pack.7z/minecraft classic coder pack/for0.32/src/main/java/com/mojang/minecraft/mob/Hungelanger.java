package com.mojang.minecraft.mob;

import com.mojang.minecraft.Entity;
import com.mojang.minecraft.level.Level;

public class Hungelanger extends Zombie {

	public Hungelanger(Level var1, float var2, float var3, float var4) {
		super(var1, var2, var3, var4);
		this.textureName = "/char.png";
	}



}
