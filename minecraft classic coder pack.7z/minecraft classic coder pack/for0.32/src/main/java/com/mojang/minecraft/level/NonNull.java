package com.mojang.minecraft.level;

public @interface NonNull {

}
