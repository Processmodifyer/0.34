package com.mojang.minecraft.level.tile;

public class ArrowItem extends DragableItem {

	protected ArrowItem(int id, int textureID) {
		super(62, 52);
	}

}
