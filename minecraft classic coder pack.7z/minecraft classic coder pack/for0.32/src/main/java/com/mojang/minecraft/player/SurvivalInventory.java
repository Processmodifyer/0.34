package com.mojang.minecraft.player;

public class SurvivalInventory {

	public SurvivalInventory() {
		// TODO Auto-generated constructor stub
	}

}
