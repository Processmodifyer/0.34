package com.mojang.minecraft;

public class KeyBinding
{
	public KeyBinding(String name, int key)
	{
		this.name = name;
		this.key = key;
	}

	public String name;
	public int key;
}
