package com.mojang.minecraft.mob;

import com.mojang.minecraft.level.Level;
import com.mojang.minecraft.mob.ai.BasicAttackAI;

final class Skeleton$1 extends BasicAttackAI {

   public static final long serialVersionUID = 0L;
   // $FF: synthetic field
   final Skeleton parent;


   Skeleton$1(Skeleton var1) {
      this.parent = var1;
   }

   public final void tick(Level var1, Mob var2) {
      super.tick(var1, var2);
	  parent.shootArrow(level);  
   }

   public final void beforeRemove() {
      Skeleton.shootRandomArrow(this.parent);
   }
}
