package com.mojang.minecraft.gui;

import com.mojang.minecraft.item.Arrow;
import com.mojang.minecraft.item.Item;
import com.mojang.minecraft.level.Level;
import com.mojang.minecraft.mob.HumanoidMob;
import com.mojang.minecraft.mob.Hungelanger;
import com.mojang.minecraft.player.Player;

public final class CheatMenu extends GuiScreen {

   private CheatMenu pausa;
   private float xloc;
   private float yloc;
   private float zloc;
   private Level level;
private float yRot;
private float z;
private float y;
private float x;
private float xRot;
private Player player;

public CheatMenu(PauseScreen pauseScreen) {
	// TODO Auto-generated constructor stub
}

public final void onOpen() {
      this.buttons.clear();
      this.buttons.add(new Button(0, this.width / 2 - 100, this.height / 4, "Set Health to 20"));
      this.buttons.add(new Button(2, this.width / 2 - 100, this.height / 4 + 48, "Die"));
      this.buttons.add(new Button(3, this.width / 2 - 100, this.height / 4 + 72, "Heal"));
      this.buttons.add(new Button(4, this.width / 2 - 100, this.height / 4 + 120, "Hungelanger"));

     if(this.minecraft.session == null) {
         //((Button)this.buttons.get(2)).active = false;
         //((Button)this.buttons.get(3)).active = false;
      }

      if(this.minecraft.networkManager != null) {
         //((Button)this.buttons.get(1)).active = false;
         //((Button)this.buttons.get(3)).active = false;
      }

   }

   protected final void onButtonClick(Button var1) {
      if(var1.id == 0) {
          this.minecraft.player.health = 20;
    	  }

         if(var1.id == 2) {
             this.minecraft.player.hurt(null, 20);
         }

         if(var1.id == 3) {
            this.minecraft.player.heal(5);
         }
         if(var1.id == 4) {
     		this.minecraft.level.addEntity(new HumanoidMob(this.minecraft.level, this.minecraft.player.x, this.minecraft.player.y, this.minecraft.player.z));	   
          }         
      }

   

   public final void render(int var1, int var2) {
      drawFadingBox(0, 0, this.width, this.height, 1610941696, -1607454624);
      drawCenteredString(this.fontRenderer, "Cheats", this.width / 2, 40, 16777215);
      super.render(var1, var2);
   }
}
