package com.mojang.minecraft.mob.md3;

public class Md3Helper {

	public Md3Helper(Object a2) {
		// TODO Auto-generated constructor stub
	}


	public Object n1;

}
