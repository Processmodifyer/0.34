package com.oyasunadev.mcraft.client.core;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import com.mojang.minecraft.MinecraftApplet;

public class MCraftApplet extends MinecraftApplet
		{
			/**
			 * Default constructor.
			 */
			public MCraftApplet()
			{
				parameters = new HashMap<String, String>();
			}

			/**
			 * Fake the Document Base.
			 *
			 * @return new URL("http://minecraft.net:80/play.jsp")
			 */
			@Override
			public URL getDocumentBase()
			{
				try {
					return new URL("http://minecraft.net:80/play.jsp");
				} catch (MalformedURLException e) {
					e.printStackTrace();
				}

				return null;
			}

			/**
			 * Fake the Code Base.
			 *
			 * @return new URL("http://minecraft.net:80/")
			 */
			@Override
			public URL getCodeBase()
			{
				try {
					return new URL("http://minecraft.net:80/");
				} catch (MalformedURLException e) {
					e.printStackTrace();
				}

				return null;
			}

			/**
			 * Return our own parameters variable.
			 *
			 * @param name
			 * @return
			 */
			@Override
			public String getParameter(String name)
			{
				return parameters.get(name);
			}

			/**
			 * Use our own parameters map.
			 */
			private Map<String, String> parameters;
		}
