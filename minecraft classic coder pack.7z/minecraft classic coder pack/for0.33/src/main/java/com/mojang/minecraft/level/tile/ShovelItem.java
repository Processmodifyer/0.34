package com.mojang.minecraft.level.tile;

public class ShovelItem extends DragableItem {

    private static Block[] minableBlocks;

    public ShovelItem(int id, int textureid) {
        super(77, 80, ShovelItem.minableBlocks);
    }
    
    static {
    	ShovelItem.minableBlocks = new Block[] { Block.GRASS, Block.DIRT, Block.SAND, Block.GRAVEL };
    }
}