// 
// Decompiled by Procyon v0.5.36
// 

package com.mojang.minecraft;

import java.io.FileNotFoundException;
import java.io.OutputStream;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.DataInputStream;
import java.util.Iterator;
import java.net.URLConnection;
import java.io.IOException;
import java.net.URL;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.io.File;

public class ResourceDownloadThread extends Thread
{
    private File dir;
    private Minecraft minecraft;
    boolean running;
    private boolean finished;
    private int progress;
    
    public ResourceDownloadThread(final File minecraftFolder, final Minecraft minecraft) {
        this.running = false;
        this.finished = false;
        this.progress = 0;
        this.minecraft = minecraft;
        this.setName("Resource download thread");
        this.setDaemon(true);
        this.dir = new File(minecraftFolder, "resources/");
        if (!this.dir.exists() && !this.dir.mkdirs()) {
            throw new RuntimeException("The working directory could not be created: " + this.dir);
        }
    }
    
    @Override
    public void run() {
        BufferedReader reader = null;
        Label_1834: {
            try {
                final ArrayList<String> list = new ArrayList<String>();
                final URL base = this.getClass().getProtectionDomain().getCodeSource().getLocation();
                final URL url = this.getClass().getResource("/index.html");

                String line = null;

                for (final String s : list) {
                    final String[] split = s.split(",");
                    final int size = Integer.parseInt(split[1]);
                    final File file = new File(this.dir, split[0]);
                    final File musicFolder = new File(this.dir, "music");
                    Label_0752: {
                        if (file.exists()) {
                            if (file.length() == size) {
                                break Label_0752;
                            }
                        }
                        try {
                            file.getParentFile().mkdirs();
                        }
                        catch (SecurityException e) {
                            e.printStackTrace();
                        }
                        final URL url2 = new URL(base, "res/" + split[0].replaceAll(" ", "%20"));
                        if (file.getPath().contains("music")) {
                            if (file.getName().equals("calm1.ogg") && !new File(musicFolder, "calm1.ogg").exists()) {
                                this.download(url2, file, size);
                            }
                            else if (file.getName().equals("calm2.ogg") && !new File(musicFolder, "calm2.ogg").exists()) {
                                this.download(url2, file, size);
                            }
                            else if (file.getName().equals("calm3.ogg") && !new File(musicFolder, "calm3.ogg").exists()) {
                                this.download(url2, file, size);
                            }
                            else if (file.getName().equals("calm4.ogg") && !new File(musicFolder, "calm4.ogg").exists()) {
                                this.download(url2, file, size);
                                System.out.println("Extraction finished");
                            }
                            else if (file.getName().equals("hal1.ogg") && !new File(musicFolder, "calm5.ogg").exists()) {
                                this.download(url2, file, size);
                            }
                            else if (file.getName().equals("hal2.ogg") && !new File(musicFolder, "calm6.ogg").exists()) {
                                this.download(url2, file, size);
                            }
                            else if (file.getName().equals("hal3.ogg") && !new File(musicFolder, "calm7.ogg").exists()) {
                                this.download(url2, file, size);
                            }
                            else if (file.getName().equals("hal4.ogg") && !new File(musicFolder, "calm8.ogg").exists()) {
                                this.download(url2, file, size);
                            }
                            else if (file.getName().equals("piano1.ogg") && !new File(musicFolder, "calm9.ogg").exists()) {
                                this.download(url2, file, size);
                            }
                            else if (file.getName().equals("piano2.ogg") && !new File(musicFolder, "calm10.ogg").exists()) {
                                this.download(url2, file, size);
                            }
                            else if (file.getName().equals("piano3.ogg") && !new File(musicFolder, "calm11.ogg").exists()) {
                                this.download(url2, file, size);
                            }
                        }
                        else {
                            this.download(url2, file, size);
                        }
                    }
                    final File minecraftOGG = new File(musicFolder, "calm1.ogg");
                    final File clarkOGG = new File(musicFolder, "calm2.ogg");
                    final File swedenOGG = new File(musicFolder, "calm3.ogg");
                    final File calm4OGG = new File(musicFolder, "calm4.ogg");
                    final File hal1OGG = new File(musicFolder, "hal1.ogg");
                    final File hal2OGG = new File(musicFolder, "hal2.ogg");
                    final File hal3OGG = new File(musicFolder, "hal3.ogg");
                    final File hal4OGG = new File(musicFolder, "hal4.ogg");
                    final File piano1OGG = new File(musicFolder, "piano1.ogg");
                    final File piano2OGG = new File(musicFolder, "piano2.ogg");
                    final File piano3OGG = new File(musicFolder, "piano3.ogg");
                    minecraftOGG.renameTo(new File(musicFolder, "calm1.ogg"));
                    clarkOGG.renameTo(new File(musicFolder, "calm2.ogg"));
                    swedenOGG.renameTo(new File(musicFolder, "calm3.ogg"));
                    calm4OGG.renameTo(new File(musicFolder, "calm4.ogg"));
                    hal1OGG.renameTo(new File(musicFolder, "calm5.ogg"));
                    hal2OGG.renameTo(new File(musicFolder, "calm6.ogg"));
                    hal3OGG.renameTo(new File(musicFolder, "calm7.ogg"));
                    hal4OGG.renameTo(new File(musicFolder, "calm8.ogg"));
                    piano1OGG.renameTo(new File(musicFolder, "calm9.ogg"));
                    piano2OGG.renameTo(new File(musicFolder, "calm10.ogg"));
                    piano3OGG.renameTo(new File(musicFolder, "calm11.ogg"));
                }
                final File soundsFolder = new File(this.dir, "sound");
                final File stepsFolder = new File(soundsFolder, "step");
                final File randomFolder = new File(soundsFolder, "random");
                for (int i = 1; i <= 4; ++i) {
                    this.minecraft.sound.registerSound(new File(stepsFolder, "grass" + i + ".ogg"), "step/grass" + i + ".ogg");
                    this.minecraft.sound.registerSound(new File(stepsFolder, "gravel" + i + ".ogg"), "step/gravel" + i + ".ogg");
                    this.minecraft.sound.registerSound(new File(stepsFolder, "stone" + i + ".ogg"), "step/stone" + i + ".ogg");
                    this.minecraft.sound.registerSound(new File(stepsFolder, "wood" + i + ".ogg"), "step/wood" + i + ".ogg");
                    this.minecraft.sound.registerSound(new File(stepsFolder, "snow" + i + ".ogg"), "step/snow" + i + ".ogg");
                }
                this.minecraft.sound.registerSound(new File(randomFolder, "wood click.ogg"), "random/wood click.ogg");
                this.minecraft.sound.registerSound(new File(randomFolder, "fizz.ogg"), "random/fizz.ogg");
                this.minecraft.sound.registerSound(new File(randomFolder, "classic_hurt.ogg"), "random/hurt.ogg");
                this.minecraft.sound.registerSound(new File(randomFolder, "explode.ogg"), "random/explode.ogg");
                this.minecraft.sound.registerSound(new File(randomFolder, "pop.ogg"), "random/pop.ogg");
                this.minecraft.sound.registerSound(new File(randomFolder, "drr.ogg"), "random/drr.ogg");
                this.minecraft.sound.registerSound(new File(randomFolder, "fuse.ogg"), "random/fuse.ogg");
                final File musicFolder2 = new File(this.dir, "music");
                for (int j = 1; j <= 11; ++j) {
                    this.minecraft.sound.registerMusic("calm" + j + ".ogg", new File(musicFolder2, "calm" + j + ".ogg"));
                }
            }
            catch (IOException e2) {
                e2.printStackTrace();
                try {
                    if (reader != null) {
                        reader.close();
                    }
                }
                catch (IOException e3) {
                    e3.printStackTrace();
                }
                break Label_1834;
            }
            finally {
                try {
                    if (reader != null) {
                        reader.close();
                    }
                }
                catch (IOException e3) {
                    e3.printStackTrace();
                }
            }
            try {
                if (reader != null) {
                    reader.close();
                }
            }
            catch (IOException e3) {
                e3.printStackTrace();
            }
        }
        this.finished = true;
    }
    
    private void download(final URL url, final File file, final int size) {
        System.out.println("Extracting: " + file.getName() + "...");
        DataInputStream in = null;
        DataOutputStream out = null;
        try {
            final byte[] data = new byte[4096];
            in = new DataInputStream(url.openStream());
            final FileOutputStream fos = new FileOutputStream(file);
            out = new DataOutputStream(fos);
            int done = 0;
            do {
                final int length = in.read(data);
                if (length < 0) {
                    in.close();
                    out.close();
                    return;
                }
                out.write(data, 0, length);
                done += length;
                this.progress = (int)(done / (double)size * 100.0);
            } while (!this.running);
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        catch (IOException e2) {
            e2.printStackTrace();
        }
        finally {
            try {
                if (in != null) {
                    in.close();
                }
                if (out != null) {
                    out.close();
                }
            }
            catch (IOException e3) {
                e3.printStackTrace();
            }
        }
        try {
            if (in != null) {
                in.close();
            }
            if (out != null) {
                out.close();
            }
        }
        catch (IOException e3) {
            e3.printStackTrace();
        }
        this.progress = 0;
        System.out.println("Extracted: " + file.getName());
    }
    
    public boolean isFinished() {
        return this.finished;
    }
    
    public int getProgress() {
        return this.progress;
    }
}