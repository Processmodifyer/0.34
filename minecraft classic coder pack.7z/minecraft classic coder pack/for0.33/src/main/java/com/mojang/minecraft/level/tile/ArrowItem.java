package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.Entity;
import com.mojang.minecraft.Minecraft;
import com.mojang.minecraft.level.Level;
import com.mojang.minecraft.mob.HumanoidMob;

public class ArrowItem extends DragableItem {

	private Minecraft minecraft;
	protected ArrowItem(int id, int textureID) {
		super(62, 52);
	}

}
