package com.mojang.minecraft;

public class EasterEgg {

}
