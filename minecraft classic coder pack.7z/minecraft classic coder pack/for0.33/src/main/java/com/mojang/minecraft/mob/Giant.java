package com.mojang.minecraft.mob;

import com.mojang.minecraft.level.Level;
import com.mojang.minecraft.mob.ai.BasicAI;
import com.mojang.minecraft.mob.ai.BasicAttackAI;


public class Giant extends Zombie {
	   /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	

	public Giant(Level var1, float var2, float var3, float var4) {
		      super(var1, var2, var3, var4);
		      this.modelName = "zombie";
		      this.textureName = "/mob/zombie.png";
		      this.heightOffset = 6.0f;
		      this.setSize(6.0F, 6.0F);		      
		      BasicAI var5 = new  BasicAI();
		      this.deathScore = 80;
		      var5.defaultLookAngle = 30;
		      var5.runSpeed = 1.0F;
		      this.bbHeight *= 6.0f;
		      this.setSize(this.z * 6.0f, this.x * 6.0f);		      
		      this.ai = var5;
		   }
		}