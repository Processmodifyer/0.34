package com.mojang.minecraft;

import java.io.File;

public enum NewOS {
    LINUX("linux", 0), SOLARIS("solaris", 1), WINDOWS("windows", 2) {
        public File getMinecraftFolder(String home, String folder) {
            String appData = System.getenv("APPDATA");

            if (appData != null) {
                return new File(appData, folder + '/');
            } else {
                return new File(home, folder + '/');
            }
        }
    }, MAC_OS_X("macos", 3) {
        public File getMinecraftFolder(String home, String folder) {
            return new File(home, "Library/Application Support/" + folder);
        }
    }, UNKNOWN("unknown", 4);

    public static final NewOS[] values = new NewOS[]{LINUX, SOLARIS, WINDOWS,
            MAC_OS_X, UNKNOWN};
    public final String folderName;
    public final int id;

    private NewOS(String folderName, int id) {
        this.folderName = folderName;
        this.id = id;
    }

    /* Windows and OSX override this */
    public File getMinecraftFolder(String home, String folder) {
        return new File(home, folder + '/');
    }

    public static NewOS detect() {
        String s = System.getProperty("os.name").toLowerCase();
        if (s.contains("win")) {
            return NewOS.WINDOWS;
        }
        if (s.contains("mac")) {
            return NewOS.MAC_OS_X;
        }
        if (s.contains("solaris") || s.contains("sunos")) {
            return NewOS.SOLARIS;
        }
        if (s.contains("linux") || s.contains("unix")) {
            return NewOS.LINUX;
        }
        return NewOS.UNKNOWN;
    }
}