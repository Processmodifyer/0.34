package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.Minecraft;
import com.mojang.minecraft.level.Level;
import com.mojang.minecraft.player.Player;

public class DragableItem extends FlowerBlock {

	private Player player;
	public static DragableItem items;
	private Level level;
	public boolean onAdded;
	protected DragableItem(int id, int textureID) {
		this(id, textureID, null);

		textureId = textureID;
	}

	public DragableItem(int id, int i, Block[] minableBlocks) {
		super(id, 0);
	}

	
	
	protected int getTextureId(int texture)
	{
		return textureId;
	}
	public void onAdded(Level level, int x, int y, int z) {
		level.setTile(x, y, z, 0);
	       }
	    		 
}

	

