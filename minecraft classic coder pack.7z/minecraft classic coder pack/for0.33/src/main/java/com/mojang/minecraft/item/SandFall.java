// 
// Decompiled by Procyon v0.5.36
// 

package com.mojang.minecraft.item;

import com.mojang.minecraft.render.ShapeRenderer;
import org.lwjgl.opengl.GL11;
import com.mojang.minecraft.render.TextureManager;
import com.mojang.minecraft.level.tile.Block;
import com.mojang.minecraft.level.Level;
import com.mojang.minecraft.Entity;

public class SandFall extends Entity
{
    public static final long serialVersionUID = 0L;
    private float xd;
    private float yd;
    private float zd;
    private int id;
    
    public SandFall(final Level var1, final float var2, final float var3, final float var4, final int id) {
        super(var1);
        this.setSize(0.98f, 0.98f);
        this.heightOffset = this.bbHeight / 2.0f;
        this.setPos(var2, var3, var4);
        this.id = id;
        this.xd = 0.0f;
        this.yd = 0.0f;
        this.zd = 0.0f;
        this.makeStepSound = false;
        this.xo = var2;
        this.yo = var3;
        this.zo = var4;
    }
    
    public void hurt(final Entity var1, final int var2) {
    }
    
    public boolean isPickable() {
        return !this.removed;
    }
    
    public void tick() {
        this.xo = this.x;
        this.yo = this.y;
        this.zo = this.z;
        this.yd -= 0.04f;
        this.move(this.xd, this.yd, this.zd);
        this.xd *= 0.98f;
        this.yd *= 0.98f;
        this.zd *= 0.98f;
        if (this.onGround) {
            this.xd *= 0.7f;
            this.zd *= 0.7f;
            this.yd *= -0.5f;
            final int Tile = this.level.getTile((int)this.x, (int)this.y, (int)this.z);
            if (Tile == 0 || Tile == Block.WATER.id || Tile == Block.STATIONARY_WATER.id || Tile == Block.LAVA.id || Tile == Block.STATIONARY_LAVA.id) {
                if (this.id == Block.SAND.id) {
                    this.level.setTile((int)this.x, (int)this.y, (int)this.z, Block.SAND.id);
                }
                else {
                    this.level.setTile((int)this.x, (int)this.y, (int)this.z, Block.GRAVEL.id);
                }
            }
            else if (Tile == Block.SAND.id || Tile == Block.GRAVEL.id) {
                this.level.setTile((int)this.x, (int)this.y, (int)this.z, this.id);
            }
            else if (!this.level.creativeMode) {
                this.level.addEntity((Entity)new Item(this.level, this.x, this.y, this.z, this.id));
            }
            this.level.playSound("step.gravel", this, 0.5f, 1.0f);
            this.remove();
        }
    }
    
    public void playerTouch(final Entity var1) {
    }
    
    public void render(final TextureManager var1, final float var2) {
        final int var3 = var1.load("/terrain.png");
        GL11.glBindTexture(3553, var3);
        final float var4 = this.level.getBrightness((int)this.x, (int)this.y, (int)this.z);
        GL11.glPushMatrix();
        GL11.glColor4f(var4, var4, var4, 0.005f);
        GL11.glTranslatef(this.xo + (this.x - this.xo) * var2 - 0.5f, this.yo + (this.y - this.yo) * var2 - 0.5f, this.zo + (this.z - this.zo) * var2 - 0.5f);
        GL11.glPushMatrix();
        final ShapeRenderer var5 = ShapeRenderer.instance;
        if (this.id == Block.SAND.id) {
            Block.SAND.renderPreview(var5);
        }
        else {
            Block.GRAVEL.renderPreview(var5);
        }
        GL11.glDisable(3553);
        GL11.glDisable(2896);
        GL11.glEnable(3042);
        GL11.glBlendFunc(770, 1);
        if (this.id == Block.SAND.id) {
            Block.SAND.renderPreview(var5);
        }
        else {
            Block.GRAVEL.renderPreview(var5);
        }
        GL11.glDisable(3042);
        GL11.glEnable(3553);
        GL11.glEnable(2896);
        GL11.glPopMatrix();
        GL11.glPopMatrix();
    }
}