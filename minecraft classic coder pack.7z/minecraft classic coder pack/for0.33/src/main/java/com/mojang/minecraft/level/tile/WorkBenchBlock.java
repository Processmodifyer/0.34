package com.mojang.minecraft.level.tile;

import com.mojang.minecraft.gui.ChatInputScreen;
import com.mojang.minecraft.player.Player;

public final class WorkBenchBlock extends Block {

   public WorkBenchBlock(int var1, int var2) {
      super(54, 26);
   }

   protected final int getTextureId(int texture) {
	      return texture == 0?this.textureId + 2:(texture == 1?this.textureId + 1:this.textureId);
	   }

   public final int getDropCount() {
      return 1;
   }
   public final int getDrop() {
       return Block.WOOD.getDrop();
   }


       
   }      


