package com.mojang.minecraft.statuseffect;

public class StatusEffect {
	public void Infict() {
		
		}
	}
