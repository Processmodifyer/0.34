package com.mojang.minecraft.mob.ai;

import com.mojang.minecraft.Entity;
import com.mojang.minecraft.item.Arrow;
import com.mojang.minecraft.player.Player;

public class NeutralAI extends BasicAI {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Player player;

	public void hurt(Entity var1, int var2) {
	      super.hurt(var1, var2);


	         this.attackTarget = var1;		
	         super.hurt(var1, var2);
	}
	@Override
	public void beforeRemove() {
		super.beforeRemove();     
	}
 }