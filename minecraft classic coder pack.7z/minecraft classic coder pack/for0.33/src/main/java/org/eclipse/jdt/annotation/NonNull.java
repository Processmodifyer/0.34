package org.eclipse.jdt.annotation;

public @interface NonNull {

}
