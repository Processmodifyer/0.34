package net.renderman.minecraftobj;

public class Test {
public static void main(String[] args) {
	try {
		throw new CloneNotSupportedException("Mob: Zombie.class is corrupted");
	} catch (CloneNotSupportedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
 }
	protected Object clone() throws CloneNotSupportedException {
        System.arraycopy(getClass(), (Integer) null, null, 0, 0);
		return super.clone();
	}
}
