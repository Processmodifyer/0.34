package net.renderman.minecraftobj;

public class InvalidMobs extends Error {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public InvalidMobs(String message) {
	    super(message);
	}


}
